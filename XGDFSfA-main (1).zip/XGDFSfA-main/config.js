    // ประกาศค่า URL ที่ใช้เชื่อมต่อกับ Web App
    const WEB_APP_MEMBER_URL = 'https://script.google.com/macros/s/AKfycbxKtQXKqAOxIOb8Pgh6Gg3h6-YHj8WnPTC0Lhl-Gq_aFSfWXoxfMRSo2vKFY7pa8yP6EQ/exec';
    const WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbwLkcQkCQppkiiGRrGT6yN6O4KPbPaJAeOlgtv3u6yGh2aF0ubVNgIi4oDIyslajxUj/exec';
    const WEB_APP_Leave_URL = 'https://script.google.com/macros/s/AKfycbwrOQM3tM7HDvjVCvpkl7heP9U4hH4kEDOIzGjF2g_l031mo4Mt83sMEzBociiOnil17Q/exec';
    const WEB_APP_OT_URL = 'https://script.google.com/macros/s/AKfycbwVrPgsYUVE2EIur5p6QuRnx_Xk7mkkV1tkeowLsPKWvXmAnPMHaRPMgWX51BOlRuhosA/exec';

//LIFF_ID
    const LIFF_ID = '2006740306-qp2xNvgM'; // LIFF ID Checkin
    const LIFF_ID1 = '2006740306-qLWyP3w6'; // LIFF ID history
    const LIFF_ID2 = '2006740306-r6ekvl6x'; // LIFF ID leave
    const LIFF_ID3 = '2006740306-pO7Gq31W'; // LIFF ID ot
    const LIFF_ID4 = '2006740306-qlr7J9go'; // LIFF ID register
